from flask import Flask, send_file, send_from_directory, request
import os

app = Flask(__name__)

# Diretório onde os arquivos TMX e TSX estão localizados
BASE_DIR = "C:/Users/wacpr/OneDrive/Documentos/jogo//"

@app.route('/api/get_map_tmx', methods=['GET'])
def get_map_tmx():
    # Caminho para o arquivo TMX
    tmx_file_path = os.path.join(BASE_DIR, "map.tmx")

    # Verifica se o arquivo existe
    if os.path.exists(tmx_file_path):
        # Envia o arquivo TMX para o cliente
        return send_file(tmx_file_path, as_attachment=True)
    else:
        return "Arquivo TMX não encontrado", 404

@app.route('/api/get_tileset', methods=['GET'])
def get_tileset():
    try:
        # Obtém o nome do arquivo TSX a partir do parâmetro de consulta
        tsx_filename = request.args.get('filename')

        # Caminho completo para o arquivo TSX
        tsx_file_path = os.path.join(BASE_DIR, tsx_filename)

        # Verifica se o arquivo TSX existe
        if os.path.exists(tsx_file_path):
            # Envia o arquivo TSX para o cliente
            return send_file(tsx_file_path, as_attachment=True)
        else:
            return "Arquivo TSX não encontrado", 404
    except Exception as e:
        return f"Erro: {e}", 500


if __name__ == '__main__':
    # Executa o aplicativo Flask em todas as interfaces na porta 4000
    app.run(debug=True, host='0.0.0.0', port=3000)
