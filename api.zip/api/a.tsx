<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="a" tilewidth="64" tileheight="64" tilecount="168" columns="8">
 <image source="Downloads/opentibia_sprite_pack-master (1)/opentibia_sprite_pack-master/sprite_sheets/otsp_doors_01.png" width="512" height="1376"/>
</tileset>
