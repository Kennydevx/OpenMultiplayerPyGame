<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tiles" class="tiles" tilewidth="32" tileheight="32" tilecount="1008" columns="16">
 <image source="../../../Downloads/opentibia_sprite_pack-master (1)/opentibia_sprite_pack-master/sprite_sheets/otsp_tiles_01.png" width="512" height="2016"/>
 <tile id="1" type="tiles"/>
</tileset>
