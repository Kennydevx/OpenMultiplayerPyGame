<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="b" tilewidth="32" tileheight="32" tilecount="1008" columns="16">
 <image source="Downloads/opentibia_sprite_pack-master (1)/opentibia_sprite_pack-master/sprite_sheets/otsp_tiles_01.png" width="512" height="2016"/>
 <tile id="17" type="tiles"/>
 <tile id="225" type="tiles"/>
 <wangsets>
  <wangset name="Conjunto Sem Nome" type="mixed" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="-1" probability="1"/>
   <wangtile tileid="33" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="34" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="37" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="49" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="50" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="51" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="52" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="53" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="54" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="55" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="56" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
